/*
 * Copyright (c) 2010 Apple Inc. All rights reserved.
 *
 * @APPLE_LLVM_LICENSE_HEADER@
 */

// BlockTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


extern int main(int argc, _TCHAR *argv[]);

int _tmain(int argc, _TCHAR* argv[])
{
    main(argc, argv);
	return 0;
}
