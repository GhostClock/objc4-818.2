int bazData = 5;


int baz()
{
	return bazData;
}
