
void foo() {}
void bar() {}
void baz() {}
