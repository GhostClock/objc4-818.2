/*
 * Copyright (c) 1999 Apple Computer, Inc. All rights reserved.
 *
 * @APPLE_LICENSE_HEADER_START@
 * 
 * This file contains Original Code and/or Modifications of Original Code
 * as defined in and that are subject to the Apple Public Source License
 * Version 2.0 (the 'License'). You may not use this file except in
 * compliance with the License. Please obtain a copy of the License at
 * http://www.opensource.apple.com/apsl/ and read it before using this
 * file.
 * 
 * The Original Code and all software distributed under the License are
 * distributed on an 'AS IS' basis, WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESS OR IMPLIED, AND APPLE HEREBY DISCLAIMS ALL SUCH WARRANTIES,
 * INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, QUIET ENJOYMENT OR NON-INFRINGEMENT.
 * Please see the License for the specific language governing rights and
 * limitations under the License.
 * 
 * @APPLE_LICENSE_HEADER_END@
 */
/*
 *	Copyright (c) 1998, Apple Computer Inc. All rights reserved.
 *
 *	File: _setjmp.h
 *
 *	Defines for register offsets in the save area.
 *
 */

#if defined(__arm__)

#define JMP_r4		0x00
#define JMP_r5		0x04
#define JMP_r6		0x08
#define JMP_r7		0x0c
#define JMP_r8		0x10
#define JMP_r10		0x14
#define JMP_fp		0x18
#define JMP_sp		0x1c
#define JMP_lr		0x20

#define JMP_VFP		0x24

#define JMP_sigmask	0x68
#define JMP_sigonstack	0x6C

#define STACK_SSFLAGS	8 // offsetof(stack_t, ss_flags)


#define JMP_SIGFLAG	0x70

#else
#error architecture not supported
#endif
